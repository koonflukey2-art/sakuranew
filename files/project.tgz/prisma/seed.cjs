const { PrismaClient, Role, AdPlatform, CampaignStatus } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Starting seed...");

  // ลบข้อมูลเก่า
  await prisma.metricsPlan.deleteMany();
  await prisma.automationRule.deleteMany();
  await prisma.adCampaign.deleteMany();
  await prisma.budget.deleteMany();
  await prisma.product.deleteMany();
  await prisma.user.deleteMany();
  await prisma.organization.deleteMany();

  // 0. สร้าง Organization ก่อน
  console.log("🏢 Creating organization...");

  const org = await prisma.organization.create({
    data: {
      name: "Demo Organization",
      slug: "demo-org",
      description: "Default organization for testing",
    },
  });

  console.log("✅ Organization created:", org.slug);

  // 1. Create Users
  console.log("👤 Creating users...");

  const adminPassword = await bcrypt.hash("admin123", 10);
  const userPassword = await bcrypt.hash("user123", 10);

  const admin = await prisma.user.create({
    data: {
      email: "admin@test.com",
      password: adminPassword,
      name: "Admin User",
      role: Role.ADMIN,
      organizationId: org.id,
    },
  });

  await prisma.user.create({
    data: {
      email: "staff@test.com",
      password: userPassword,
      name: "Stock Staff",
      role: Role.STOCK,
      organizationId: org.id,
    },
  });

  await prisma.user.create({
    data: {
      email: "user@test.com",
      password: userPassword,
      name: "Regular User",
      role: Role.EMPLOYEE,
      organizationId: org.id,
    },
  });

  console.log("✅ Users created");

  // 2. Products
  console.log("📦 Creating products...");

  const products = await Promise.all([
    prisma.product.create({
      data: {
        name: "ครีมกันแดด SPF50+",
        category: "Skincare",
        quantity: 150,
        minStockLevel: 50,
        costPrice: 250,
        sellPrice: 499,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "เซรั่มวิตามินซี",
        category: "Skincare",
        quantity: 80,
        minStockLevel: 30,
        costPrice: 350,
        sellPrice: 699,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "ลิปสติกเนื้อแมท",
        category: "Makeup",
        quantity: 200,
        minStockLevel: 50,
        costPrice: 150,
        sellPrice: 299,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "คุชชั่นกันแดด",
        category: "Makeup",
        quantity: 45,
        minStockLevel: 50,
        costPrice: 400,
        sellPrice: 799,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "แชมพูบำรุงเส้นผม",
        category: "Haircare",
        quantity: 120,
        minStockLevel: 40,
        costPrice: 180,
        sellPrice: 349,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "วิตามินซี 1000mg",
        category: "Supplement",
        quantity: 25,
        minStockLevel: 30,
        costPrice: 200,
        sellPrice: 399,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "คอลลาเจนผง",
        category: "Supplement",
        quantity: 90,
        minStockLevel: 40,
        costPrice: 450,
        sellPrice: 899,
        organizationId: org.id,
      },
    }),
    prisma.product.create({
      data: {
        name: "เสื้อยืดผ้าฝ้าย",
        category: "Fashion",
        quantity: 180,
        minStockLevel: 60,
        costPrice: 120,
        sellPrice: 249,
        organizationId: org.id,
      },
    }),
  ]);

  console.log(`✅ Created ${products.length} products`);

  // 3. Ad Campaigns
  console.log("📢 Creating ad campaigns...");

  const campaigns = await Promise.all([
    prisma.adCampaign.create({
      data: {
        platform: AdPlatform.FACEBOOK,
        campaignName: "กันแดด Summer Sale",
        budget: 10000,
        spent: 8500,
        reach: 45000,
        clicks: 2300,
        conversions: 180,
        roi: 2.8,
        status: CampaignStatus.ACTIVE,
        startDate: new Date("2025-11-15"),
        endDate: new Date("2025-12-15"),
        organizationId: org.id,
      },
    }),
    prisma.adCampaign.create({
      data: {
        platform: AdPlatform.TIKTOK,
        campaignName: "Vitamin C Serum Viral",
        budget: 15000,
        spent: 12000,
        reach: 120000,
        clicks: 8500,
        conversions: 320,
        roi: 3.5,
        status: CampaignStatus.ACTIVE,
        startDate: new Date("2025-11-10"),
        endDate: new Date("2025-12-10"),
        organizationId: org.id,
      },
    }),
    prisma.adCampaign.create({
      data: {
        platform: AdPlatform.GOOGLE,
        campaignName: "11.11 Mega Sale (Shopee)",
        budget: 20000,
        spent: 20000,
        reach: 80000,
        clicks: 4500,
        conversions: 450,
        roi: 4.2,
        status: CampaignStatus.COMPLETED,
        startDate: new Date("2025-11-01"),
        endDate: new Date("2025-11-11"),
        organizationId: org.id,
      },
    }),
    prisma.adCampaign.create({
      data: {
        platform: AdPlatform.LINE,
        campaignName: "Flash Sale วันนี้ (Lazada)",
        budget: 8000,
        spent: 3500,
        reach: 35000,
        clicks: 1800,
        conversions: 95,
        roi: 2.1,
        status: CampaignStatus.ACTIVE,
        startDate: new Date("2025-11-20"),
        endDate: new Date("2025-11-30"),
        organizationId: org.id,
      },
    }),
    prisma.adCampaign.create({
      data: {
        platform: AdPlatform.FACEBOOK,
        campaignName: "Retargeting - Cart Abandonment",
        budget: 5000,
        spent: 4200,
        reach: 15000,
        clicks: 950,
        conversions: 120,
        roi: 3.8,
        status: CampaignStatus.ACTIVE,
        startDate: new Date("2025-11-18"),
        organizationId: org.id,
      },
    }),
  ]);

  console.log(`✅ Created ${campaigns.length} campaigns`);

  // 4. Budgets
  console.log("💰 Creating budgets...");

  const budgets = await Promise.all([
    prisma.budget.create({
      data: {
        amount: 50000,
        purpose: "Facebook Ads - November",
        spent: 35000,
        startDate: new Date("2025-11-01"),
        endDate: new Date("2025-11-30"),
        organizationId: org.id,
      },
    }),
    prisma.budget.create({
      data: {
        amount: 30000,
        purpose: "TikTok Ads - November",
        spent: 22000,
        startDate: new Date("2025-11-01"),
        endDate: new Date("2025-11-30"),
        organizationId: org.id,
      },
    }),
    prisma.budget.create({
      data: {
        amount: 25000,
        purpose: "E-commerce Platform Ads",
        spent: 18500,
        startDate: new Date("2025-11-01"),
        endDate: new Date("2025-11-30"),
        organizationId: org.id,
      },
    }),
    prisma.budget.create({
      data: {
        amount: 15000,
        purpose: "Content Creation",
        spent: 8000,
        startDate: new Date("2025-11-01"),
        endDate: new Date("2025-11-30"),
        organizationId: org.id,
      },
    }),
    prisma.budget.create({
      data: {
        amount: 10000,
        purpose: "Influencer Marketing",
        spent: 7500,
        startDate: new Date("2025-11-15"),
        endDate: new Date("2025-12-15"),
        organizationId: org.id,
      },
    }),
  ]);

  console.log(`✅ Created ${budgets.length} budgets`);

  // 5. Automation Rules (userId = admin.id)
  console.log("⚡ Creating automation rules...");

  await Promise.all([
    prisma.automationRule.create({
      data: {
        platform: "Facebook Ads",
        tool: "Revealbot",
        ruleName: "หยุดโฆษณา CPA สูงเกิน 200 บาท",
        condition: { metric: "CPA", operator: ">", value: 200 },
        action: { type: "pauseCampaign" },
        isActive: true,
        userId: admin.id,
      },
    }),
    prisma.automationRule.create({
      data: {
        platform: "Facebook Ads",
        tool: "Revealbot",
        ruleName: "เพิ่มงบ 20% เมื่อ ROAS > 3.0",
        condition: { metric: "ROAS", operator: ">", value: 3 },
        action: { type: "increaseBudget", value: 20 },
        isActive: true,
        userId: admin.id,
      },
    }),
    prisma.automationRule.create({
      data: {
        platform: "TikTok Ads",
        tool: "Custom",
        ruleName: "แจ้งเตือนเมื่อ CTR < 1%",
        condition: { metric: "CTR", operator: "<", value: 1 },
        action: { type: "sendNotification" },
        isActive: false,
        userId: admin.id,
      },
    }),
  ]);

  console.log("✅ Automation rules created");

  // 6. Metrics Plans
  console.log("📊 Creating metrics plans...");

  await Promise.all([
    prisma.metricsPlan.create({
      data: {
        templateName: "Growth Plan",
        targets: {
          revenue: 100000,
          cac: 500,
          ltv: 2000,
          conversionRate: 3.5,
          roas: 3.0,
        },
        actual: {
          revenue: 85000,
          cac: 450,
          ltv: 1800,
          conversionRate: 3.2,
          roas: 3.2,
        },
        period: "monthly",
        userId: admin.id,
      },
    }),
    prisma.metricsPlan.create({
      data: {
        templateName: "Profit Plan",
        targets: {
          grossProfit: 50000,
          netProfit: 30000,
          profitMargin: 30,
        },
        actual: {
          grossProfit: 42000,
          netProfit: 25000,
          profitMargin: 27,
        },
        period: "monthly",
        userId: admin.id,
      },
    }),
  ]);

  console.log("✅ Metrics plans created");

  console.log("");
  console.log("🎉 Seed completed successfully!");
  console.log("");
  console.log("📝 Test Accounts:");
  console.log("   Admin: admin@test.com / admin123");
  console.log("   Staff: staff@test.com / user123");
  console.log("   User : user@test.com / user123");
  console.log("");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
