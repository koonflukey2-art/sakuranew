"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Package,
  ShoppingCart,
  BarChart3,
} from "lucide-react";
import { ExportButton } from "@/components/export-button";
import { formatDataForExport } from "@/lib/export";

interface AnalyticsData {
  overview?: {
    totalRevenue?: number;
    revenueChange?: number;
    totalOrders?: number;
    ordersChange?: number;
    totalProducts?: number;
    productsChange?: number;
    avgOrderValue?: number;
    avgOrderChange?: number;
    totalAdSpend?: number;
    activeCampaigns?: number;
    avgCampaignROI?: number;
  };
  topProducts?: Array<{
    id: string;
    name: string;
    category: string;
    revenue: number;
    quantity: number;
  }>;
  topCategories?: Array<{
    category: string;
    revenue: number;
    percentage: number;
  }>;
  revenueByMonth?: Array<{
    month: string;
    revenue: number;
  }>;
  campaignPerformance?: Array<{
    platform: string;
    spent: number;
    roi: number;
    conversions: number;
  }>;
  adPerformanceByPlatform?: Array<{
    platform: string;
    campaigns: number;
    totalSpend: number;
    avgROI: number;
    totalConversions: number;
  }>;
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState("30");

  useEffect(() => {
    fetchAnalytics();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateRange]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await fetch(`/api/analytics?days=${dateRange}`);
      if (!res.ok) {
        throw new Error("Failed to fetch analytics");
      }
      const analytics = await res.json();
      setData(analytics || {});
    } catch (error) {
      console.error("Error fetching analytics:", error);
      setError("ไม่สามารถโหลดข้อมูลการวิเคราะห์ได้");
      setData({});
    } finally {
      setLoading(false);
    }
  };

  if (loading && !data) {
    return (
      <div className="space-y-4 md:space-y-6 text-white">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <h1 className="text-2xl md:text-3xl font-bold text-white">
            การวิเคราะห์
          </h1>
        </div>
        <Card className="bg-white/5 border border-white/15">
          <CardContent className="p-6">
            <div className="text-center text-gray-400">กำลังโหลด...</div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const safeData = data ?? {};
  const rawOverview = safeData.overview ?? {};

  const overview = {
    totalRevenue: rawOverview.totalRevenue ?? 0,
    revenueChange: rawOverview.revenueChange ?? 0,
    totalOrders: rawOverview.totalOrders ?? 0,
    ordersChange: rawOverview.ordersChange ?? 0,
    totalProducts: rawOverview.totalProducts ?? 0,
    productsChange: rawOverview.productsChange ?? 0,
    avgOrderValue: rawOverview.avgOrderValue ?? 0,
    avgOrderChange: rawOverview.avgOrderChange ?? 0,
    totalAdSpend: rawOverview.totalAdSpend ?? 0,
    activeCampaigns: rawOverview.activeCampaigns ?? 0,
    avgCampaignROI: rawOverview.avgCampaignROI ?? 0,
  };

  const topProducts = safeData.topProducts ?? [];
  const topCategories = safeData.topCategories ?? [];
  const revenueByMonth = safeData.revenueByMonth ?? [];
  const campaignPerformance = safeData.campaignPerformance ?? [];
  const adPerformanceByPlatform = safeData.adPerformanceByPlatform ?? [];

  const exportProducts = formatDataForExport(topProducts, {
    id: "รหัส",
    name: "สินค้า",
    category: "หมวดหมู่",
    revenue: "รายได้",
    quantity: "จำนวนที่ขาย",
  });

  const exportCategories = formatDataForExport(topCategories, {
    category: "หมวดหมู่",
    revenue: "รายได้",
    percentage: "เปอร์เซ็นต์",
  });

  const exportRevenue = formatDataForExport(revenueByMonth, {
    month: "เดือน",
    revenue: "รายได้",
  });

  const exportCampaigns = formatDataForExport(campaignPerformance, {
    platform: "แพลตฟอร์ม",
    spent: "ค่าใช้จ่าย",
    roi: "ROI",
    conversions: "การแปลง",
  });

  return (
    <div className="space-y-4 md:space-y-6 text-white">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-white">
            การวิเคราะห์
          </h1>
          <p className="text-sm md:text-base text-gray-400 mt-1">
            ภาพรวมธุรกิจและประสิทธิภาพ
          </p>
        </div>
        <div className="flex gap-2 items-center w-full sm:w-auto">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40 bg-white/5 border border-white/15 text-white">
              <SelectValue placeholder="เลือกช่วงเวลา" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border border-white/15 text-white">
              <SelectItem value="7">7 วันที่แล้ว</SelectItem>
              <SelectItem value="30">30 วันที่แล้ว</SelectItem>
              <SelectItem value="90">90 วันที่แล้ว</SelectItem>
              <SelectItem value="365">1 ปีที่แล้ว</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {loading && (
        <Card className="bg-white/5 border border-white/15">
          <CardContent className="p-6">
            <div className="text-center text-gray-400">กำลังโหลด...</div>
          </CardContent>
        </Card>
      )}

      {!loading && error && (
        <Card className="bg-white/5 border border-white/15">
          <CardContent className="p-6">
            <div className="text-center text-gray-400">{error}</div>
          </CardContent>
        </Card>
      )}

      {/* Overview Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        {/* 4 การ์ดแรก + 3 การ์ดโฆษณา เหมือนโค้ดเดิม เปลี่ยนสีเล็กน้อยถ้าต้องการ */}
        {/* ผมคง className เดิมไว้ เพราะคอนทราสต์โอเคแล้ว */}
        {/* ... 7 cards overview เดิมของคุณ ... */}
      </div>

      {/* Top Products */}
      <Card className="bg-white/5 border border-white/15">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <CardTitle className="text-lg md:text-xl text-white">
            สินค้าขายดี
          </CardTitle>
          <div className="w-full sm:w-auto">

            <ExportButton
            data={exportProducts}
            filename={`top-products-${dateRange}days`}
            columns={[
              { header: "สินค้า", dataKey: "สินค้า" },
              { header: "หมวดหมู่", dataKey: "หมวดหมู่" },
              { header: "รายได้", dataKey: "รายได้" },
              { header: "จำนวนที่ขาย", dataKey: "จำนวนที่ขาย" },
            ]}
            title="สินค้าขายดี"
          />

          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topProducts.map((product, index) => (
              <div
                key={product.id}
                className="flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 flex items-center justify-center bg-purple-500/40 rounded-full text-white font-bold">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-medium text-white">{product.name}</p>
                    <p className="text-sm text-gray-400">
                      {product.category}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-green-400">
                    ฿{product.revenue.toLocaleString("th-TH")}
                  </p>
                  <p className="text-sm text-gray-400">
                    ขาย {product.quantity} ชิ้น
                  </p>
                </div>
              </div>
            ))}
            {topProducts.length === 0 && (
              <p className="text-center text-gray-400">
                ยังไม่มีข้อมูลสินค้าขายดี
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Top Categories */}
      <Card className="bg-white/5 border border-white/15">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <CardTitle className="text-lg md:text-xl text-white">
            หมวดหมู่ยอดนิยม
          </CardTitle>
          <div className="w-full sm:w-auto">
            <ExportButton
           
            data={exportCategories}
            filename={`top-categories-${dateRange}days`}
            columns={[
              { header: "หมวดหมู่", dataKey: "หมวดหมู่" },
              { header: "รายได้", dataKey: "รายได้" },
              { header: "เปอร์เซ็นต์", dataKey: "เปอร์เซ็นต์" },
            ]}
            title="หมวดหมู่ยอดนิยม"
           />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {topCategories.map((category) => (
              <div key={category.category} className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-white">
                    {category.category}
                  </p>
                  <p className="text-sm text-gray-400">
                    ฿{category.revenue.toLocaleString("th-TH")} (
                    {category.percentage.toFixed(1)}%)
                  </p>
                </div>
                <div className="w-full bg-white/10 rounded-full h-2">
                  <div
                    className="bg-blue-500 h-2 rounded-full"
                    style={{ width: `${category.percentage}%` }}
                  />
                </div>
              </div>
            ))}
            {topCategories.length === 0 && (
              <p className="text-center text-gray-400">
                ยังไม่มีข้อมูลหมวดหมู่
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Campaign Performance */}
      <Card className="bg-white/5 border border-white/15">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <CardTitle className="text-lg md:text-xl text-white">
            ประสิทธิภาพแคมเปญ
          </CardTitle>
          <div className="w-full sm:w-auto">
            <ExportButton
           
            data={exportCampaigns}
            filename={`campaigns-${dateRange}days`}
            columns={[
              { header: "แพลตฟอร์ม", dataKey: "แพลตฟอร์ม" },
              { header: "ค่าใช้จ่าย", dataKey: "ค่าใช้จ่าย" },
              { header: "ROI", dataKey: "ROI" },
              { header: "การแปลง", dataKey: "การแปลง" },
            ]}
            title="ประสิทธิภาพแคมเปญ"
           />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {campaignPerformance.map((campaign) => (
              <div
                key={campaign.platform}
                className="flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors"
              >
                <div>
                  <p className="font-medium text-white">
                    {campaign.platform}
                  </p>
                  <p className="text-sm text-gray-400">
                    ค่าใช้จ่าย: ฿
                    {campaign.spent.toLocaleString("th-TH")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-purple-300">
                    ROI: {campaign.roi}x
                  </p>
                  <p className="text-sm text-gray-400">
                    {campaign.conversions} การแปลง
                  </p>
                </div>
              </div>
            ))}
            {campaignPerformance.length === 0 && (
              <p className="text-center text-gray-400">
                ยังไม่มีข้อมูลแคมเปญโฆษณา
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Ad performance by platform */}
      <Card className="bg-white/5 border border-white/15">
        <CardHeader className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <CardTitle className="text-lg md:text-xl text-white">
            ประสิทธิภาพโฆษณาต่อแพลตฟอร์ม
          </CardTitle>
        </CardHeader>
        <CardContent>
          {adPerformanceByPlatform.length === 0 ? (
            <p className="text-sm text-gray-400 text-center">
              ยังไม่มีข้อมูลแคมเปญโฆษณา
            </p>
          ) : (
            <div className="space-y-3">
              {adPerformanceByPlatform.map((item) => (
                <div
                  key={item.platform}
                  className="flex items-center justify-between p-3 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors"
                >
                  <div>
                    <p className="font-medium text-white">
                      {item.platform}
                    </p>
                    <p className="text-xs text-gray-400">
                      แคมเปญ: {item.campaigns} | การแปลง:{" "}
                      {item.totalConversions}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-200">
                      ใช้จ่าย: ฿
                      {item.totalSpend.toLocaleString("th-TH")}
                    </p>
                    <p className="text-xs text-gray-400">
                      ROI เฉลี่ย: {item.avgROI.toFixed(2)}x
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
