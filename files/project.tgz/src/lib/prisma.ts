export { prisma } from "./db";
