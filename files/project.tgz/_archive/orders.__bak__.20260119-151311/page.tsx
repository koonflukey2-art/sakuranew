"use client";



import OrdersOverlayLoading from "./_ui/OrdersOverlayLoading";
import OrdersPdfDownload from "./_ui/OrdersPdfDownload";
// ✅ key วันแบบ local (ตามเวลาเครื่องผู้ใช้) เพื่อกรอง "วันนี้" ให้ตรงจริง
function localDateKey(input: any) {
  const d = new Date(input ?? 0);
  if (isNaN(d.getTime())) return "invalid";
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

import { useMemo, useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ConfirmDialog } from "@/components/confirm-dialog";
import { Switch } from "@/components/ui/switch";
import {
  Search,
  Edit,
  User,
  Phone,
  MapPin,
  Calendar,
  ShoppingCart,
  RefreshCw,
  Trash2,
  Plus,
  Wand2,
} from "lucide-react";

// ✅ ใช้ parser ตัวเดิมของคุณ (ที่แก้ phone/address แล้ว)
import { parseLineMessage } from "@/lib/line-parser";

interface Order {
  id: string;
  orderNumber?: string;
  customer: {
    name: string;
    phone: string;
    address?: string;
  };
  productType?: number;
  productName?: string;
  amount: number;
  quantity: number;
  status: string;
  orderDate: string;
  notes?: string;
  cancelledAt?: string | null;
  cancelledByUserId?: string | null;
}

interface ProductType {
  productType: number;
  name: string;
  currentStock: number;
}

const ITEMS_PER_PAGE = 10;

// key สำหรับช่วงเวลา
type DateRangeKey = "today" | "today" | "3d" | "7d" | "1m" | "3m" | "1y" | "ALL";

type CreateForm = {
  productType: string; // เก็บเป็น string เพื่อ bind กับ Select/Input ง่าย
  productName: string;
  amount: string;
  quantity: string;
  customerName: string;
  phone: string;
  address: string;
  status: "PENDING" | "CONFIRMED" | "COMPLETED" | "CANCELLED";
  notes: string;
  rawMessage: string; // วางข้อความ LINE ได้
};

const DEFAULT_FORM: CreateForm = {
  productType: "1",
  productName: "",
  amount: "",
  quantity: "1",
  customerName: "",
  phone: "",
  address: "",
  status: "COMPLETED",
  notes: "",
  rawMessage: "",
};

export default function OrdersPage() {
const [__busy, __setBusy] = useState(true);

useEffect(() => {
  const t = setTimeout(() => __setBusy(false), 500);
  return () => clearTimeout(t);
}, []);
  const [orders, setOrders] = useState<Order[]>([]);
  const [productTypes, setProductTypes] = useState<ProductType[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  // ใช้ "ALL" แทนค่ารวมทั้งหมด (ห้ามปล่อยเป็น "")
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [productTypeFilter, setProductTypeFilter] = useState<string>("ALL");

  // ช่วงเวลา (default: 7 วันล่าสุด)
  const [dateRange, setDateRange] = useState<DateRangeKey>("today");

  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [confirmEditOpen, setConfirmEditOpen] = useState(false);
  const [userRole, setUserRole] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const [submitting, setSubmitting] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState("");
  const [showCancelled, setShowCancelled] = useState(false);

  // ✅ เพิ่ม: create dialog
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [confirmCreateOpen, setConfirmCreateOpen] = useState(false);
  const [createForm, setCreateForm] = useState<CreateForm>(DEFAULT_FORM);

  const { toast } = useToast();

  useEffect(() => {
    fetchOrders({ resetPage: true });
fetchUserRole();
    fetchProductTypes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, statusFilter, productTypeFilter, dateRange, showCancelled]);

  const fetchUserRole = async () => {
    try {
      const res = await fetch("/api/me");
      if (res.ok) {
        const data = await res.json();
        setUserRole(data.role);
      }
    } catch (error) {
      console.error("Failed to fetch user role:", error);
    }
  };

  const fetchProductTypes = async () => {
    try {
      const res = await fetch("/api/products/types");
      if (res.ok) {
        const data = await res.json();
        setProductTypes(data);
      }
    } catch (error) {
      console.error("Failed to fetch product types:", error);
    }
  };

  
  /**
   * ทำช่วงเวลา "วันไทย" (UTC+7) แล้วส่งเป็น ISO (UTC) ไป query ที่ API
   */
  const bkkDayStartUtcIso = (base = new Date()) => {
    const utcMs = base.getTime() + base.getTimezoneOffset() * 60000;
    const bkk = new Date(utcMs + 7 * 3600 * 1000);
    bkk.setHours(0, 0, 0, 0);
    const startUtc = new Date(bkk.getTime() - 7 * 3600 * 1000);
    return startUtc.toISOString();
  };

// helper สำหรับคำนวณวันที่เริ่มต้นตามช่วงเวลา
  const getDateRange = (range: DateRangeKey) => {
    if (range === "ALL") return null;

    const now = new Date();
    const from = new Date(now);

      let to = new Date(now);
switch (range) {
      
        case "today":
          return { from: bkkDayStartUtcIso(now), to: to.toISOString() };
case "3d":
        from.setDate(now.getDate() - 3);
        break;
      case "7d":
        from.setDate(now.getDate() - 7);
        break;
      case "1m":
        from.setMonth(now.getMonth() - 1);
        break;
      case "3m":
        from.setMonth(now.getMonth() - 3);
        break;
      case "1y":
        from.setFullYear(now.getFullYear() - 1);
        break;
    }

    return {
      from: from.toISOString(),
      to: to.toISOString(),
    };
  };

  const fetchOrders = async (opts?: { resetPage?: boolean }) => {
    try {
      setLoading(true);
      const params = new URLSearchParams();

      if (search) params.append("search", search);
      if (statusFilter !== "ALL" && !showCancelled) params.append("status", statusFilter);
      if (productTypeFilter !== "ALL")
        params.append("productType", productTypeFilter);

      const range = getDateRange(dateRange);
      if (range) {
        params.append("from", range.from);
        params.append("to", range.to);
      }

      const res = await fetch(`/api/orders?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setOrders(data);
        if (opts?.resetPage ?? true) setCurrentPage(1);
      }
    } catch (error) {
      console.error("Failed to fetch orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => fetchOrders({ resetPage: true });const handleUpdateOrder = async () => {
    if (!selectedOrder) return;

    try {
      setSubmitting(true);
      const res = await fetch("/api/orders", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: selectedOrder.id,
          customerName: selectedOrder.customer.name,
          customerPhone: selectedOrder.customer.phone,
          customerAddress: selectedOrder.customer.address,
          amount: selectedOrder.amount,
          status: selectedOrder.status,
          notes: selectedOrder.notes,
        }),
      });

      if (res.ok) {
        toast({
          title: "✅ บันทึกสำเร็จ",
          description: "อัพเดทข้อมูลออเดอร์แล้ว",
        });
        setConfirmEditOpen(false);
        setEditDialogOpen(false);
        fetchOrders({ resetPage: false });
} else {
        const error = await res.json();
        toast({
          title: "❌ ไม่สามารถบันทึกได้",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "❌ เกิดข้อผิดพลาด",
        description: "ไม่สามารถอัพเดทข้อมูลได้",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteOrder = async () => {
    if (!selectedOrder) return;

    try {
      setSubmitting(true);
      const res = await fetch(`/api/orders?id=${selectedOrder.id}`, {
        method: "DELETE",
      });

      if (res.ok) {
        toast({
          title: "✅ ลบสำเร็จ",
          description: "ลบออเดอร์เรียบร้อยแล้ว",
        });
        setDeleteDialogOpen(false);
        setSelectedOrder(null);
        fetchOrders({ resetPage: false });
} else {
        const error = await res.json();
        toast({
          title: "❌ ไม่สามารถลบได้",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "❌ เกิดข้อผิดพลาด",
        description: "ไม่สามารถลบออเดอร์ได้",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelOrder = async () => {
    if (!selectedOrder) return;

    try {
      setSubmitting(true);
      const res = await fetch("/api/orders", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: selectedOrder.id,
          status: "CANCELLED",
          cancelReason,
        }),
      });

      if (res.ok) {
        toast({
          title: "✅ ยกเลิกออเดอร์สำเร็จ",
          description: "บันทึกสถานะการยกเลิกแล้ว",
        });
        setCancelDialogOpen(false);
        setCancelReason("");
        fetchOrders({ resetPage: false });
} else {
        const error = await res.json();
        toast({
          title: "❌ ไม่สามารถยกเลิกได้",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "❌ เกิดข้อผิดพลาด",
        description: "ไม่สามารถยกเลิกออเดอร์ได้",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  // ✅ เพิ่ม: สร้างออเดอร์ใหม่
  const handleCreateOrder = async () => {
    try {
      setSubmitting(true);

      const payload = {
        productType: parseInt(createForm.productType, 10),
        productName: createForm.productName || null,
        amount: parseFloat(createForm.amount),
        quantity: parseInt(createForm.quantity, 10),
        customerName: createForm.customerName,
        customerPhone: createForm.phone,
        customerAddress: createForm.address,
        status: createForm.status,
        notes: createForm.notes,
        rawMessage: createForm.rawMessage || null,
      };

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data?.error || "Create failed");
      }

      toast({ title: "✅ เพิ่มออเดอร์สำเร็จ", description: "บันทึกออเดอร์แล้ว" });

      setConfirmCreateOpen(false);
      setCreateDialogOpen(false);
      setCreateForm(DEFAULT_FORM);
      fetchOrders({ resetPage: false });
} catch (err: any) {
      toast({
        title: "❌ เพิ่มออเดอร์ไม่สำเร็จ",
        description: err?.message || "เกิดข้อผิดพลาด",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleParseFromLineText = () => {
    const raw = createForm.rawMessage?.trim();
    if (!raw) {
      toast({
        title: "กรุณาวางข้อความก่อน",
        description: "วางข้อความจาก LINE แล้วกดแปลง",
        variant: "destructive",
      });
      return;
    }

    const parsed = parseLineMessage(raw);
    if (!parsed) {
      toast({
        title: "แปลงไม่สำเร็จ",
        description: "รูปแบบข้อความยังไม่ถูกต้อง",
        variant: "destructive",
      });
      return;
    }

    setCreateForm((prev) => ({
      ...prev,
      productType: String(parsed.productType),
      productName: (parsed as any).productName || "",
      amount: String(parsed.amount ?? ""),
      quantity: String(parsed.quantity ?? 1),
      customerName: parsed.customerName || "",
      phone: parsed.phone || "",
      address: parsed.address || "",
    }));

    toast({
      title: "✅ แปลงสำเร็จ",
      description: "เติมข้อมูลให้แล้ว ตรวจสอบก่อนบันทึก",
    });
  };

  const getStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      PENDING: "bg-yellow-500",
      CONFIRMED: "bg-blue-500",
      COMPLETED: "bg-green-500",
      CANCELLED: "bg-red-500",
    };
    const labels: Record<string, string> = {
      PENDING: "รอดำเนินการ",
      CONFIRMED: "ยืนยันแล้ว",
      COMPLETED: "สำเร็จ",
      CANCELLED: "ยกเลิก",
    };
    return <Badge className={colors[status]}>{labels[status] || status}</Badge>;
  };

  const getCancelReason = (notes?: string) => {
    if (!notes) return null;
    const marker = "ยกเลิก:";
    const index = notes.lastIndexOf(marker);
    if (index === -1) return null;
    return notes.slice(index + marker.length).trim();
  };

  const isCancelled = (st: string) => st === "CANCELLED" || st === "CANCELED";
  const cancelledOrders = orders.filter((o) => isCancelled(o.status));
  const nonCancelledOrders = orders.filter((o) => !isCancelled(o.status));

  const visibleOrders =
    statusFilter === "CANCELLED"
      ? cancelledOrders
      : statusFilter === "ALL"
      ? nonCancelledOrders
      : nonCancelledOrders.filter((o) => o.status === statusFilter);

  /**
   * ✅ map ลำดับออเดอร์ "ตามวันไทย" (UTC+7)
   * - กลุ่มตามวัน (วันไทย)
   * - เรียงเวลา ASC แล้วให้ index 1..N
   */
  const dailySeqMap = useMemo(() => {
    const toBkkKey = (d: Date) => {
      const bkk = new Date(d.getTime() + 7 * 3600 * 1000);
      return bkk.toISOString().slice(0, 10); // YYYY-MM-DD
    };

    const groups = new Map<string, Order[]>();
    for (const o of orders) {
      const dt = new Date((o as any).orderDate ?? (o as any).createdAt ?? Date.now());
      const key = toBkkKey(dt);
      groups.set(key, [...(groups.get(key) ?? []), o]);
    }

    const map = new Map<string, number>();
    for (const [, list] of groups) {
      const sorted = [...list].sort((a: any, b: any) => {
        const ad = new Date(a.orderDate ?? a.createdAt ?? 0).getTime();
        const bd = new Date(b.orderDate ?? b.createdAt ?? 0).getTime();
        return ad - bd;
      });
      sorted.forEach((o, idx) => map.set(o.id, idx + 1));
    }
    // ✅ หน้าเริ่มต้น: ถ้าเลือก "วันนี้" ให้โชว์เฉพาะออเดอร์ของวันนี้
    return map;
  }, [orders]);
  // alias ให้ชื่อที่ใช้ใน UI
  const orderDayIndexMap = dailySeqMap;

  // ✅ ใช้ตัวนี้แทน visibleOrders เพื่อให้หน้าเริ่มต้นโชว์เฉพาะ "วันนี้"
  const visibleOrdersFiltered = useMemo(() => {
    if (dateRange !== "today") return visibleOrders;
    const todayKey = localDateKey(new Date());
    return visibleOrders.filter((o: any) => {
      const dt = o.orderDate ?? o.createdAt ?? o.updatedAt ?? 0;
      return localDateKey(dt) === todayKey;
    });
  }, [visibleOrders, dateRange]);



const totalPages =
    visibleOrdersFiltered.length === 0
      ? 1
      : Math.ceil(visibleOrdersFiltered.length / ITEMS_PER_PAGE);

  // ✅ ถ้าหน้าเดิมเกิน totalPages ให้ clamp ลงมา
  useEffect(() => {
    setCurrentPage((p) => Math.min(Math.max(1, p), totalPages));
  }, [totalPages]);


  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const paginatedOrders = visibleOrdersFiltered.slice(startIndex, endIndex);

  return (
    <div className="p-6 space-y-6">
      <OrdersOverlayLoading show={__busy} />
      {/* Header + actions */}
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="ml-auto">
          <OrdersPdfDownload />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gradient-pink mb-2">
            รายการออเดอร์
          </h1>
          <p className="text-gray-200 text-lg">
            รายการออเดอร์จาก LINE Webhook + เพิ่มเองได้
          </p>
        </div>

        <div className="flex gap-2">
          {userRole === "ADMIN" && (
            <Button
              size="sm"
              onClick={() => {
                setCreateForm(DEFAULT_FORM);
                setCreateDialogOpen(true);
              }}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              เพิ่มออเดอร์
            </Button>
          )}

          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={loading}
            className="border-purple-400 text-purple-200 hover:bg-purple-500/10"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            รีเฟรช
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10">
<div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div>
              <Label>ค้นหา</Label>
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="เลขออเดอร์, ชื่อ, เบอร์โทร"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div>
              <Label>สถานะ</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="ทั้งหมด" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">ทั้งหมด</SelectItem>
                  <SelectItem value="PENDING">รอดำเนินการ</SelectItem>
                  <SelectItem value="CONFIRMED">ยืนยันแล้ว</SelectItem>
                  <SelectItem value="COMPLETED">สำเร็จ</SelectItem>
                  <SelectItem value="CANCELLED">ยกเลิก</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>ประเภทสินค้า</Label>
              <Select
                value={productTypeFilter}
                onValueChange={setProductTypeFilter}
              >
                <SelectTrigger>
                  <SelectValue placeholder="ทั้งหมด" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">ทั้งหมด</SelectItem>
                  {productTypes.map((product) => (
                    <SelectItem
                      key={product.productType}
                      value={String(product.productType)}
                    >
                      {product.name} (ประเภท {product.productType})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>ช่วงเวลา</Label>
              <Select
                value={dateRange}
                onValueChange={(value) => setDateRange(value as DateRangeKey)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="ช่วงเวลา" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="today">วันนี้</SelectItem>
                  <SelectItem value="3d">3 วันล่าสุด</SelectItem>
                  <SelectItem value="7d">7 วันล่าสุด</SelectItem>
                  <SelectItem value="1m">1 เดือนล่าสุด</SelectItem>
                  <SelectItem value="3m">3 เดือนล่าสุด</SelectItem>
                  <SelectItem value="1y">1 ปีล่าสุด</SelectItem>
                  <SelectItem value="ALL">ทั้งหมด</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col justify-between gap-2">
              <Label>ออเดอร์ยกเลิก</Label>
              <div className="flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-slate-100">
                <span>แสดงรายการยกเลิก</span>
                <Switch
                  checked={showCancelled}
                  onCheckedChange={setShowCancelled}
                  disabled={statusFilter === "CANCELLED"}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      {loading ? (
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto" />
          <p className="text-gray-400 mt-4">กำลังโหลด...</p>
        </div>
      ) : visibleOrdersFiltered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10">
            <ShoppingCart className="w-16 h-16 text-gray-500 mx-auto mb-4" />
            <p className="text-gray-300">ไม่พบรายการออเดอร์</p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid gap-4">
            {paginatedOrders.map((order, index) => (
              <Card
                key={order.id}
                className="border-2 border-purple-500/40 bg-gradient-to-br from-slate-950 to-slate-900 hover:border-purple-400 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10"
              >
                        <div className="mb-2 text-xs text-slate-300/80">รายการที่ {orderDayIndexMap.get(order.id) ?? "-"}</div>
<CardContent className="pt-6 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10">
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-3 flex-1">
                      {/* Order Number & Status */}
                      <div className="flex items-center gap-3 flex-wrap">
                        <div className="bg-purple-500/10 border border-purple-400/60 rounded-lg px-3 py-1">
                          <span className="text-sm font-bold text-purple-100">
                            #{order.id.slice(0, 8).toUpperCase()}
                          </span>
                        </div>
                        {getStatusBadge(order.status)}
                        {order.notes?.includes("เก็บปลายทาง") && (
                          <Badge
                            variant="outline"
                            className="bg-amber-500/15 text-amber-200 border-amber-400/60"
                          >
                            เก็บปลายทาง
                          </Badge>
                        )}
                        <Badge
                          variant="outline"
                          className="bg-blue-500/15 text-blue-200 border-blue-400/60"
                        >
                          {productTypes.find(
                            (p) => p.productType === order.productType
                          )?.name ||
                            order.productName ||
                            `สินค้าหมายเลข ${order.productType}`}
                        </Badge>
                        <Badge
                          variant="outline"
                          className="bg-slate-700 text-slate-100 border-slate-500"
                        >
                          {order.quantity} ชิ้น
                        </Badge>
                      </div>

                      {/* Customer Info Grid */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-purple-400" />
                          <span className="font-medium text-slate-50">
                            {order.customer.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-emerald-400" />
                          <span className="text-slate-200">
                            {order.customer.phone}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-sky-400" />
                          <span className="text-slate-200">
                            {new Date(order.orderDate).toLocaleDateString(
                              "th-TH",
                              {
                                year: "numeric",
                                month: "short",
                                day: "numeric",
                                hour: "2-digit",
                                minute: "2-digit",
                              }
                            )}
                          </span>
                        </div>
                      </div>

                      {/* Address */}
                      {order.customer.address && (
                        <div className="bg-slate-900 rounded-lg p-3 border border-slate-700">
                          <div className="flex items-start gap-2">
                            <MapPin className="w-5 h-5 text-red-400 mt-0.5 flex-shrink-0" />
                            <div>
                              <div className="text-xs text-slate-400 mb-1">
                                ที่อยู่จัดส่ง
                              </div>
                              <p className="text-sm text-slate-100 leading-relaxed">
                                {order.customer.address}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Amount */}
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="inline-flex items-baseline px-3 py-1 rounded-lg border border-emerald-400/60 bg-emerald-500/10">
                            <span className="text-lg font-semibold text-emerald-300">
                              ฿{order.amount.toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>

                      {order.status === "CANCELLED" && (
                        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-100">
                          เหตุผลยกเลิก: {getCancelReason(order.notes) || "ไม่ได้ระบุ"}
                        </div>
                      )}
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2">
                      {userRole === "ADMIN" ? (
                        <>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedOrder(order);
                              setEditDialogOpen(true);
                            }}
                            className="border-purple-400 text-purple-100 hover:bg-purple-500/10"
                          >
                            <Edit className="w-4 h-4 mr-2" />
                            แก้ไข
                          </Button>
                          {order.status !== "CANCELLED" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedOrder(order);
                                setCancelReason("");
                                setCancelDialogOpen(true);
                              }}
                              className="border-orange-400 text-orange-100 hover:bg-orange-500/10"
                            >
                              ยกเลิก
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSelectedOrder(order);
                              setDeleteDialogOpen(true);
                            }}
                            className="border-red-400 text-red-100 hover:bg-red-500/10"
                          >
                            <Trash2 className="w-4 h-4 mr-2" />
                            ลบ
                          </Button>
                        </>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          ดูอย่างเดียว
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-between mt-6 flex-wrap gap-3">
            <p className="text-sm text-gray-300">
              แสดง {startIndex + 1} - {Math.min(endIndex, visibleOrdersFiltered.length)} จาก{" "}
              {visibleOrdersFiltered.length} รายการ
            </p>
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                className="border-slate-500 text-slate-100"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              >
                ก่อนหน้า
              </Button>
              <span className="text-sm text-gray-200">
                หน้า {currentPage} / {totalPages}
              </span>
              <Button
                size="sm"
                variant="outline"
                className="border-slate-500 text-slate-100"
                disabled={currentPage === totalPages}
                onClick={() =>
                  setCurrentPage((p) => Math.min(totalPages, p + 1))
                }
              >
                ถัดไป
              </Button>
            </div>
          </div>

          {showCancelled && statusFilter !== "CANCELLED" && cancelledOrders.length > 0 && (
            <div className="mt-10 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-red-200">
                    ออเดอร์ที่ยกเลิก
                  </h2>
                  <p className="text-sm text-red-200/70">
                    แยกไว้เพื่อไม่รบกวนรายการที่ยังใช้งาน
                  </p>
                </div>
                <Badge className="bg-red-500/20 text-red-100 border border-red-500/40">
                  {cancelledOrders.length} รายการ
                </Badge>
              </div>
              <div className="grid gap-4">
                {cancelledOrders.map((order) => (
                  <Card
                    key={order.id}
                    className="border border-red-500/30 bg-gradient-to-br from-slate-950 to-slate-900 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10"
                  >
                    <CardContent className="pt-6 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-purple-500/10">
                      <div className="flex items-start justify-between gap-4">
                        <div className="space-y-3 flex-1">
                          <div className="flex items-center gap-3 flex-wrap">
                            <div className="bg-red-500/10 border border-red-400/60 rounded-lg px-3 py-1">
                              <span className="text-sm font-bold text-red-100">
                                #{order.id.slice(0, 8).toUpperCase()}
                              </span>
                            </div>
                            {getStatusBadge(order.status)}
                            <Badge
                              variant="outline"
                              className="bg-slate-700 text-slate-100 border-slate-500"
                            >
                              {order.quantity} ชิ้น
                            </Badge>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                            <div className="flex items-center gap-2">
                              <User className="w-4 h-4 text-purple-400" />
                              <span className="font-medium text-slate-50">
                                {order.customer.name}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Phone className="w-4 h-4 text-emerald-400" />
                              <span className="text-slate-200">
                                {order.customer.phone}
                              </span>
                            </div>
                          </div>

                          <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-xs text-red-100">
                            เหตุผลยกเลิก: {getCancelReason(order.notes) || "ไม่ได้ระบุ"}
                          </div>
                        </div>

                        <div className="flex gap-2">
                          {userRole === "ADMIN" ? (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedOrder(order);
                                setEditDialogOpen(true);
                              }}
                              className="border-purple-400 text-purple-100 hover:bg-purple-500/10"
                            >
                              <Edit className="w-4 h-4 mr-2" />
                              แก้ไข
                            </Button>
                          ) : (
                            <Badge variant="secondary" className="text-xs">
                              ดูอย่างเดียว
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Order Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>➕ เพิ่มออเดอร์ (พิมพ์มือ / วางข้อความ LINE)</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label>วางข้อความจาก LINE (ถ้ามี)</Label>
              <Textarea
                value={createForm.rawMessage}
                onChange={(e) =>
                  setCreateForm((p) => ({ ...p, rawMessage: e.target.value }))
                }
                placeholder={`ตัวอย่าง:\n2\nยอดเก็บ390\nประนอมอินสุภา 79 หมู่ 8 ... 062-223-6733\n3`}
                rows={4}
              />

              <div className="flex justify-end mt-2">
                {/* ✅ FIX: ปุ่มแปลงข้อความให้อ่านชัด ไม่กลืนกับกรอบ */}
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleParseFromLineText}
                  className="bg-purple-500/15 border-purple-400/60 text-purple-100 hover:bg-purple-500/25 hover:border-purple-300 active:bg-purple-500/30"
                >
                  <Wand2 className="w-4 h-4 mr-2" />
                  แปลงข้อความ
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>ประเภทสินค้า</Label>
                <Select
                  value={createForm.productType}
                  onValueChange={(v) =>
                    setCreateForm((p) => ({ ...p, productType: v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {productTypes.map((product) => (
                      <SelectItem
                        key={product.productType}
                        value={String(product.productType)}
                      >
                        {product.name} (ประเภท {product.productType})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>ชื่อสินค้า (ไม่ใส่ก็ได้)</Label>
                <Input
                  value={createForm.productName}
                  onChange={(e) =>
                    setCreateForm((p) => ({
                      ...p,
                      productName: e.target.value,
                    }))
                  }
                  placeholder="เช่น สบู่, ครีม..."
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>ยอดเงิน (฿)</Label>
                <Input
                  type="number"
                  value={createForm.amount}
                  onChange={(e) =>
                    setCreateForm((p) => ({ ...p, amount: e.target.value }))
                  }
                  placeholder="390"
                />
              </div>
              <div>
                <Label>จำนวน (ชิ้น)</Label>
                <Input
                  type="number"
                  value={createForm.quantity}
                  onChange={(e) =>
                    setCreateForm((p) => ({ ...p, quantity: e.target.value }))
                  }
                  placeholder="1"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>ชื่อลูกค้า</Label>
                <Input
                  value={createForm.customerName}
                  onChange={(e) =>
                    setCreateForm((p) => ({
                      ...p,
                      customerName: e.target.value,
                    }))
                  }
                  placeholder="ชื่อลูกค้า"
                />
              </div>
              <div>
                <Label>เบอร์โทร</Label>
                <Input
                  value={createForm.phone}
                  onChange={(e) =>
                    setCreateForm((p) => ({ ...p, phone: e.target.value }))
                  }
                  placeholder="062-xxx-xxxx"
                />
              </div>
            </div>

            <div>
              <Label>ที่อยู่</Label>
              <Textarea
                value={createForm.address}
                onChange={(e) =>
                  setCreateForm((p) => ({ ...p, address: e.target.value }))
                }
                placeholder="ที่อยู่จัดส่ง"
                rows={2}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>สถานะ</Label>
                <Select
                  value={createForm.status}
                  onValueChange={(v) =>
                    setCreateForm((p) => ({
                      ...p,
                      status: v as CreateForm["status"],
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PENDING">รอดำเนินการ</SelectItem>
                    <SelectItem value="CONFIRMED">ยืนยันแล้ว</SelectItem>
                    <SelectItem value="COMPLETED">สำเร็จ</SelectItem>
                    <SelectItem value="CANCELLED">ยกเลิก</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>หมายเหตุ</Label>
                <Input
                  value={createForm.notes}
                  onChange={(e) =>
                    setCreateForm((p) => ({ ...p, notes: e.target.value }))
                  }
                  placeholder="หมายเหตุ (ถ้ามี)"
                />
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setCreateDialogOpen(false)}
                disabled={submitting}
              >
                ยกเลิก
              </Button>
              <Button
                onClick={() => setConfirmCreateOpen(true)}
                disabled={submitting}
              >
                บันทึกออเดอร์
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm Create Dialog */}
      <ConfirmDialog
        open={confirmCreateOpen}
        onOpenChange={setConfirmCreateOpen}
        title="ยืนยันการเพิ่มออเดอร์"
        description={`คุณแน่ใจหรือไม่ที่จะเพิ่มออเดอร์ "${
          createForm.customerName || "-"
        }"?`}
        onConfirm={handleCreateOrder}
        confirmText="ยืนยัน"
        cancelText="ยกเลิก"
        loading={submitting}
      />

      {/* Edit Dialog / Confirm Edit / Confirm Delete (เหมือนเดิมของคุณ) */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              แก้ไขออเดอร์ #
              {selectedOrder?.orderNumber ||
                selectedOrder?.id.slice(0, 8).toUpperCase()}
            </DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>ชื่อลูกค้า</Label>
                  <Input
                    value={selectedOrder.customer.name}
                    onChange={(e) =>
                      setSelectedOrder({
                        ...selectedOrder,
                        customer: {
                          ...selectedOrder.customer,
                          name: e.target.value,
                        },
                      })
                    }
                    placeholder="ชื่อลูกค้า"
                  />
                </div>

                <div>
                  <Label>เบอร์โทรศัพท์</Label>
                  <Input
                    value={selectedOrder.customer.phone}
                    onChange={(e) =>
                      setSelectedOrder({
                        ...selectedOrder,
                        customer: {
                          ...selectedOrder.customer,
                          phone: e.target.value,
                        },
                      })
                    }
                    placeholder="เบอร์โทร"
                  />
                </div>
              </div>

              <div>
                <Label>ที่อยู่จัดส่ง</Label>
                <Textarea
                  value={selectedOrder.customer.address || ""}
                  onChange={(e) =>
                    setSelectedOrder({
                      ...selectedOrder,
                      customer: {
                        ...selectedOrder.customer,
                        address: e.target.value,
                      },
                    })
                  }
                  placeholder="ที่อยู่จัดส่ง"
                  rows={2}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label>ยอดเงิน (฿)</Label>
                  <Input
                    type="number"
                    value={selectedOrder.amount}
                    onChange={(e) =>
                      setSelectedOrder({
                        ...selectedOrder,
                        amount: parseFloat(e.target.value) || 0,
                      })
                    }
                    placeholder="ยอดเงิน"
                  />
                </div>

                <div>
                  <Label>สถานะ</Label>
                  <Select
                    value={selectedOrder.status}
                    onValueChange={(value) =>
                      setSelectedOrder({ ...selectedOrder, status: value })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PENDING">รอดำเนินการ</SelectItem>
                      <SelectItem value="CONFIRMED">ยืนยันแล้ว</SelectItem>
                      <SelectItem value="COMPLETED">สำเร็จ</SelectItem>
                      <SelectItem value="CANCELLED">ยกเลิก</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label>หมายเหตุ</Label>
                <Textarea
                  value={selectedOrder.notes || ""}
                  onChange={(e) =>
                    setSelectedOrder({
                      ...selectedOrder,
                      notes: e.target.value,
                    })
                  }
                  placeholder="เพิ่มหมายเหตุ..."
                  rows={2}
                />
              </div>

              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setEditDialogOpen(false)}
                  disabled={submitting}
                >
                  ยกเลิก
                </Button>
                <Button
                  onClick={() => setConfirmEditOpen(true)}
                  disabled={submitting}
                >
                  บันทึก
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={confirmEditOpen}
        onOpenChange={setConfirmEditOpen}
        title="ยืนยันการแก้ไข"
        description={`คุณแน่ใจหรือไม่ที่จะแก้ไขข้อมูลออเดอร์ "${selectedOrder?.customer.name}"?`}
        onConfirm={handleUpdateOrder}
        confirmText="ยืนยัน"
        cancelText="ยกเลิก"
        loading={submitting}
      />

      <ConfirmDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        title="⚠️ ยืนยันการลบ"
        description={`คุณแน่ใจหรือไม่ที่จะลบออเดอร์ "${selectedOrder?.customer.name}"? การกระทำนี้ไม่สามารถย้อนกลับได้!`}
        onConfirm={handleDeleteOrder}
        confirmText="ลบ"
        cancelText="ยกเลิก"
        variant="destructive"
        loading={submitting}
      />

      <Dialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>ยกเลิกออเดอร์</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Label>เหตุผลการยกเลิก</Label>
            <Textarea
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="ระบุเหตุผล เช่น ลูกค้าขอเปลี่ยนแปลง หรือชำระเงินไม่สำเร็จ"
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCancelDialogOpen(false)}
              disabled={submitting}
            >
              ยกเลิก
            </Button>
            <Button onClick={handleCancelOrder} disabled={submitting}>
              ยืนยันการยกเลิก
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
